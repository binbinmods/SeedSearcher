# 1.1.0

Added ability to search for specific caravan epic pairs (must be hard coded for now)

# 1.0.2

Added ability to search for a single seed (backend)

# 1.0.1

Added back-end searching for boss/guaranteed items

# 1.0.0

Initial Release